#include "Parameter.h"
#include <string>

using namespace std;

string Parameter::toString()
{
    return value;
}